/* This is an automatically generated file. Do not edit. */

/* UniKS-UCS2-V */

static const pdf_range cmap_UniKS_UCS2_V_ranges[] = {
{8211,8212,8059},
{8214,8214,8061},
{8229,8229,8058},
{12289,12290,8056},
{12296,12305,8065},
{12307,12307,8075},
{12308,12309,8063},
{65281,65281,8076},
{65288,65289,8077},
{65292,65292,8079},
{65294,65294,8080},
{65306,65311,8081},
{65339,65339,8087},
{65341,65341,8088},
{65343,65343,8089},
{65371,65373,8090},
{65374,65374,8062},
{65507,65507,8093},
};

static pdf_cmap cmap_UniKS_UCS2_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniKS-UCS2-V",
	/* usecmap */ "UniKS-UCS2-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	18, 18, (pdf_range*)cmap_UniKS_UCS2_V_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
