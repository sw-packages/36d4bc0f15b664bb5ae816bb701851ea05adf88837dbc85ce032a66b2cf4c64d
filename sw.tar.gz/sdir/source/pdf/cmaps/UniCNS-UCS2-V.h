/* This is an automatically generated file. Do not edit. */

/* UniCNS-UCS2-V */

static const pdf_range cmap_UniCNS_UCS2_V_ranges[] = {
{8211,8211,120},
{8212,8212,122},
{8229,8229,109},
{12296,12297,150},
{12298,12299,146},
{12300,12301,154},
{12302,12303,158},
{12304,12305,142},
{12308,12309,138},
{65103,65103,13745},
{65288,65289,130},
{65371,65371,134},
{65373,65373,135},
};

static pdf_cmap cmap_UniCNS_UCS2_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "UniCNS-UCS2-V",
	/* usecmap */ "UniCNS-UCS2-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	13, 13, (pdf_range*)cmap_UniCNS_UCS2_V_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
