/* This is an automatically generated file. Do not edit. */

/* B5pc-V */

static const pdf_range cmap_B5pc_V_ranges[] = {
{41291,41291,13646},
{41306,41306,13743},
{41308,41308,13745},
{41309,41310,130},
{41313,41314,134},
{41317,41318,138},
{41321,41322,142},
{41325,41326,146},
{41329,41330,150},
{41333,41334,154},
{41337,41338,158},
{41443,41443,13647},
};

static pdf_cmap cmap_B5pc_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "B5pc-V",
	/* usecmap */ "B5pc-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	12, 12, (pdf_range*)cmap_B5pc_V_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
